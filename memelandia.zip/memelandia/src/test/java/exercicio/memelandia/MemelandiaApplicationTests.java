package exercicio.memelandia;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MemelandiaApplicationTests {

	@Test
	void contextLoads() {
	}

}
